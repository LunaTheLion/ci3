<body style="background-color: white; height: 100%; margin-top: 5%; margin-right: 5%; margin-left: 5%">
<div class="container">
	Oops! Something came up!
	<br>
	<a href="<?php echo base_url('login') ?>">Back</a>
</div>	
