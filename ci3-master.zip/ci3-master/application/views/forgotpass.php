<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
</head>
<body>
This is forgot password page
<br>
<a href="<?php echo base_url('login') ?>">Back to login</a>
</body>
</html>