<!DOCTYPE html>
<html>
<head>
	<title>Facebook</title>
</head>
<body>
	Register using facebook
	<br>
<a href="<?php echo base_url('login') ?>">Back to login</a>
</body>
</html>