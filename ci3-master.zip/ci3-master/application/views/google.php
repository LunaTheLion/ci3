<!DOCTYPE html>
<html>
<head>
	<title>Register on Google</title>
</head>
<body>
Register using your google account
<br>
<a href="<?php echo base_url('login') ?>">Back to login</a>
</body>
</html>