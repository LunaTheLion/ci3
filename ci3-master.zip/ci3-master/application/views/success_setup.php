<body>
	<?php
	echo "<center>Success! Setting up Database! </center>";

	//  echo "<pre>";
	// print_r($page_data);
	// echo "</pre>"; 
					?>
<center><a href="<?php echo base_url('signin') ?>" class="btn btn-success">Back to Sign in</a></center>