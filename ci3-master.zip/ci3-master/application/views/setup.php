
<body>
<p><center>Hello This is the setup page , installing the Database
</center></p>

<div class="row">
  <div class="col-md-4"></div>
  <div class="col-md-4">
    <div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>Set up the database</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <!-- <p class="login-box-msg">Sign in to start your session</p> -->

    <form action="<?php echo base_url('admin/setup_db') ?>" method="post">
 
    
      <div class="row">
 
        <!-- /.col -->
          <button type="submit" class="btn btn-primary btn-block btn-flat">Setup Database</button>
        
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
  </div>
  <div class="col-md-4"></div>
</div>